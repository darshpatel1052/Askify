// This content script runs on the webpages the user visits
// With the WebLoader approach, we no longer need to extract content from the page directly
// The backend will now handle content extraction using LangChain's WebLoader

// Keep minimal functionality to respond to potential messages
// This could be expanded in the future for highlighting answers, etc.
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'extractContent') {
        try {
            // Just return basic metadata since actual extraction happens in the backend
            const metadata = {
                title: document.title,
                url: window.location.href,
                timestamp: new Date().toISOString()
            };

            sendResponse({
                success: true,
                data: {
                    metadata,
                    message: "Content extraction is now handled by the backend using LangChain's WebLoader"
                }
            });
        } catch (error) {
            sendResponse({ success: false, error: error.message });
        }
        return true; // Keep the message channel open for the asynchronous response
    }
});
